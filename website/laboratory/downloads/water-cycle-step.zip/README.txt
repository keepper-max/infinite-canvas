水循环的过程与地理意义 — 非商业离线教学包

使用方式：先解压 ZIP，再用 Chrome 或 Edge 打开 water-cycle-step.html。课件 HTML 与上游原文件一致，可断网使用。建议使用桌面浏览器；场景显示需要浏览器支持 WebGL。

原作者：铜匠十点睡觉
原项目：铜匠实验室 / Tongjiang Lab
原站：https://lab.tongjiang.app
原仓库：https://github.com/smithjohn78390/tongjiang-lab
来源版本：4d63ce0a72d987c850ec6d919e570bdb752c87a6
课件、封面和目录：CC BY-NC 4.0（署名—非商业性使用）
许可全文：https://creativecommons.org/licenses/by-nc/4.0/legalcode
Three.js 等第三方组件保留各自许可，参见 THIRD_PARTY_NOTICES.md。

守密人实验室提供课件分类、播放入口和离线打包；未改动课件 HTML 内容，不代表原作者授权商业使用或为本站背书。转载与改编请保留作者、来源、许可链接，并注明改动。此包仅用于非商业学习与教学。
